# Porechop tests

Porechop comes with a few automated tests to help with development and spotting bugs.

To run the tests, execute this command from Porechop's root directory:
```
python3 -m unittest
```
